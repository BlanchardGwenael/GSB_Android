package com.example.appligsb.modele.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class EchantillonDao extends SQLiteOpenHelper {
    public static final String TABLE_ECHANT = "echantillons",
            COL_ID = "_id",
            COL_CODE = "code",
            COL_LIB = "libelle",
            COL_STOCK = "quantite",
            CREATE_BDD = "CREATE TABLE " + TABLE_ECHANT + " (" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_CODE + " TEXT NOT NULL, " + COL_LIB +
                    " TEXT NOT NULL, " + COL_STOCK + " INTEGER NOT NULL);";
    public static final int NUM_COL_CODE = 0, NUM_COL_LIB = 1, NUM_COL_STOCK = 2;

    public EchantillonDao(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try{
            db.execSQL(CREATE_BDD);
        }catch (Exception e){
            System.out.println("Erreur lors de la création de la BDD ECHANTILLON : " + e.getClass() + " -> " + e.getMessage());
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ECHANT + ";");
        onCreate(db);
    }

    public void reset(SQLiteDatabase db){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ECHANT + ";");
        onCreate(db);
    }
}

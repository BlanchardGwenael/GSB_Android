package com.example.appligsb.modele;

public class Mouvement {
    private String codeMedicament, dateMouvement;
    private E_MouvementType type;
    private int quantite;

    public Mouvement(String codeMedicament, String dateMouvement, E_MouvementType type, int quantite) {
        this.codeMedicament = codeMedicament;
        this.dateMouvement = dateMouvement;
        this.type = type;
        this.quantite = quantite;
    }

    public String getCodeMedicament() {
        return codeMedicament;
    }

    public void setCodeMedicament(String codeMedicament) {
        this.codeMedicament = codeMedicament;
    }

    public String getDateMouvement() {
        return dateMouvement;
    }

    public void setDateMouvement(String dateMouvement) {
        this.dateMouvement = dateMouvement;
    }

    public E_MouvementType getType() {
        return type;
    }

    public void setType(E_MouvementType type) {
        this.type = type;
    }

    public int getQuantite() {
        return quantite;
    }

    public void setQuantite(int quantite) {
        this.quantite = quantite;
    }
}

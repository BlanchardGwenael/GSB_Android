package com.example.appligsb.modele;

public enum E_MouvementType {
    AJOUT("ajout"),
    SUPPRESSION("suppression");

    private final String labelType;

    E_MouvementType(String labelType){
        this.labelType = labelType;
    }

    @Override
    public String toString(){
        return labelType;
    }
}

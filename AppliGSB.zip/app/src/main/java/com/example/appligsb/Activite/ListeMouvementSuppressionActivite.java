package com.example.appligsb.Activite;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.annotation.Nullable;

import com.example.appligsb.R;
import com.example.appligsb.modele.E_MouvementType;
import com.example.appligsb.modele.dao.BdAdapter;
import com.example.appligsb.modele.dao.EchantillonDao;
import com.example.appligsb.modele.dao.MouvementDao;

public class ListeMouvementSuppressionActivite extends Activity {
    private ListView lstListe;
    private BdAdapter echantBdd;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activite_liste_mouvement_suppression);
        init();
        Button btnQuitter = findViewById(R.id.btn_quitter);
        btnQuitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    protected void init(){
        lstListe = findViewById(R.id.lst_liste);
        echantBdd = new BdAdapter(this);
        echantBdd.open();
        Cursor curseur = echantBdd.getMouvementData(E_MouvementType.SUPPRESSION);
        String[] nomsCol = new String[] {MouvementDao.COL_CODE, MouvementDao.COL_DATE, MouvementDao.COL_QUANTITE};
        int[] indicesCol = new int[] {R.id.txt_code, R.id.txt_date, R.id.txt_quantite};
        SimpleCursorAdapter adaptDonnees = new SimpleCursorAdapter(this, R.layout.list_movement, curseur, nomsCol, indicesCol);
        lstListe.setAdapter(adaptDonnees);
        echantBdd.close();
    }
}

package com.example.appligsb.modele.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.appligsb.modele.E_MouvementType;
import com.example.appligsb.modele.Echantillon;
import com.example.appligsb.modele.Mouvement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BdAdapter {
    static final int VERSION_BDD = 5;
    private static final String NOM_BDD = "gsb.db";

    private final EchantillonDao bdEchantillon;
    private final MouvementDao bdMouvement;
    private SQLiteDatabase dbEchantillon, dbMouvement;

    public BdAdapter(Context context){
        bdEchantillon = new EchantillonDao(context, NOM_BDD, null, VERSION_BDD);
        bdMouvement = new MouvementDao(context, NOM_BDD, null, VERSION_BDD);
    }

    public void open(){
        dbEchantillon = bdEchantillon.getWritableDatabase();
        dbMouvement = bdMouvement.getWritableDatabase();
    }

    public void close(){
        dbEchantillon.close();
        dbMouvement.close();
    }

    public boolean insertEchantillon(Echantillon echantillon){
        if(getEchantillonWithCode(echantillon.getCode()) != null){
            // Si l'échantillon existe déjà -> Mise à jour !
            return updateEchantillon(echantillon);
        } else {
            ContentValues valeurs = new ContentValues();
            valeurs.put(EchantillonDao.COL_CODE, echantillon.getCode());
            valeurs.put(EchantillonDao.COL_LIB, echantillon.getLibelle());
            valeurs.put(EchantillonDao.COL_STOCK, echantillon.getQuantiteStock());
            long resultat = dbEchantillon.insert(EchantillonDao.TABLE_ECHANT, null, valeurs);
            if(resultat != 0){
                Date dateActu = new Date();
                // Définir le format souhaité pour la date et l'heure
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss - dd/MM/yyyy", Locale.getDefault());
                // Formater la date et l'heure actuelles selon le format défini
                String dateFormatee = sdf.format(dateActu);
                return insertMouvement(new Mouvement(echantillon.getCode(), dateFormatee, E_MouvementType.AJOUT, echantillon.getQuantiteStock()));
            }else {
                return false;
            }
        }
    }

    private boolean insertMouvement(Mouvement mouvement){
        ContentValues valeurs = new ContentValues();
        valeurs.put(MouvementDao.COL_CODE, mouvement.getCodeMedicament());
        valeurs.put(MouvementDao.COL_DATE, mouvement.getDateMouvement());
        valeurs.put(MouvementDao.COL_TYPE, mouvement.getType().toString());
        valeurs.put(MouvementDao.COL_QUANTITE, mouvement.getQuantite());
        long resultat = dbMouvement.insert(MouvementDao.TABLE_MOUVEMENT, null, valeurs);
        return(resultat != 0);
    }

    private Echantillon cursorToEchant(Cursor c){
        Echantillon echantillon = null;
        if (c.getCount() != 0){
            c.moveToFirst();
            echantillon = new Echantillon(c.getString(EchantillonDao.NUM_COL_CODE), c.getString(EchantillonDao.NUM_COL_LIB), c.getInt(EchantillonDao.NUM_COL_STOCK));
        }
        c.close();
        return echantillon;
    }

    public Echantillon getEchantillonWithCode(String code){
        Cursor c = dbEchantillon.query(EchantillonDao.TABLE_ECHANT, new String[] {EchantillonDao.COL_CODE, EchantillonDao.COL_LIB, EchantillonDao.COL_STOCK},
                EchantillonDao.COL_CODE + " LIKE \"" + code + "\"", null, null, null, null);
        //Toast.makeText(context, "Code rechercher : " + code + " -> Trouvée : " + (echant != null), Toast.LENGTH_SHORT).show();
        return cursorToEchant(c);
    }

    public boolean updateEchantillon(Echantillon echantillon) {
        Echantillon echantBase = getEchantillonWithCode(echantillon.getCode());
        if (echantBase == null) {
            // Si l'échantillon n'existe pas -> création.
            return insertEchantillon(echantillon);
        } else {
            ContentValues valeurs = new ContentValues();
            valeurs.put(EchantillonDao.COL_LIB, echantillon.getLibelle());
            valeurs.put(EchantillonDao.COL_STOCK, echantillon.getQuantiteStock());
            int resultat = dbEchantillon.update(EchantillonDao.TABLE_ECHANT, valeurs, EchantillonDao.COL_CODE + " LIKE \"" + echantillon.getCode() + "\"", null);
            if (resultat != 0) {
                Date dateActu = new Date();
                // Définir le format souhaité pour la date et l'heure
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss - dd/MM/yyyy", Locale.getDefault());
                // Formater la date et l'heure actuelles selon le format défini
                String dateFormatee = sdf.format(dateActu);
                if (echantillon.getQuantiteStock() > echantBase.getQuantiteStock()) {
                    return insertMouvement(new Mouvement(echantillon.getCode(), dateFormatee, E_MouvementType.AJOUT, echantillon.getQuantiteStock() - echantBase.getQuantiteStock()));
                } else {
                    return insertMouvement(new Mouvement(echantillon.getCode(), dateFormatee, E_MouvementType.SUPPRESSION, echantBase.getQuantiteStock() - echantillon.getQuantiteStock()));
                }
            } else {
                return false;
            }
        }
    }

    public Cursor getEchantillonData(){
        try{
            return dbEchantillon.rawQuery("SELECT * FROM " + EchantillonDao.TABLE_ECHANT, null);
        }catch (Exception e){
            return null;
        }
    }

    public Cursor getMouvementData(E_MouvementType type){
        try{
            return dbEchantillon.rawQuery("SELECT * FROM " + MouvementDao.TABLE_MOUVEMENT + " WHERE " + MouvementDao.COL_TYPE + " LIKE \"" + type.toString() + "\"", null);
        }catch (Exception e){
            return null;
        }
    }

    public void resetDataBase(){
        bdEchantillon.reset(dbEchantillon);
        bdMouvement.reset(dbMouvement);
    }
}

package com.example.appligsb.modele.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MouvementDao extends SQLiteOpenHelper {
    public static final String  TABLE_MOUVEMENT = "mouvement";
    public static final String COL_ID = "_id",
            COL_CODE = "code",
            COL_DATE = "dateMouvement",
            COL_TYPE = "type",
            COL_QUANTITE = "quantite",
            CREATE_BDD = "CREATE TABLE " + TABLE_MOUVEMENT + " (" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_CODE + " TEXT NOT NULL, " + COL_DATE +
                    " DATETIME NOT NULL, " + COL_TYPE + " TEXT NOT NULL CHECK (type IN (\"ajout\",\"suppression\")), "+ COL_QUANTITE +" INT NOT NULL);";
    public static final int NUM_COL_CODE = 0,
            NUM_COL_DATE = 1,
            NUM_COL_TYPE = 3,
            NUM_COL_QUANTITE = 4;


    public MouvementDao(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try{
            db.execSQL(CREATE_BDD);
        }catch (Exception e){
            System.out.println("Erreur lors de la création de la BDD MOUVEMENT : " + e.getClass() + " -> " + e.getMessage());
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOUVEMENT + ";");
        onCreate(db);
    }

    public void reset(SQLiteDatabase db){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOUVEMENT + ";");
        onCreate(db);
    }
}

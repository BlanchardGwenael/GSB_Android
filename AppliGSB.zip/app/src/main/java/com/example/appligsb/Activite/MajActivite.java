package com.example.appligsb.Activite;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.Nullable;

import com.example.appligsb.R;
import com.example.appligsb.modele.Echantillon;
import com.example.appligsb.modele.dao.BdAdapter;
import com.example.appligsb.modele.dao.EchantillonDao;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("SetTextI18n")
public class MajActivite extends Activity {
	TextView txtMessage;
	EditText eTxtStock;

    Spinner sp_code;
	String code;
	int messageCouleur, qte;

	@Override
	protected void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activite_maj);
		init();
		Button btnAjouter = findViewById(R.id.btn_ajouter);

		btnAjouter.setOnClickListener(v -> {
            try{
                code = sp_code.getSelectedItem().toString();
                qte = Integer.parseInt(eTxtStock.getText().toString());
                BdAdapter bdd = new BdAdapter(getBaseContext());
                bdd.open();
                Echantillon echantillon = bdd.getEchantillonWithCode(code);
                if(echantillon != null){
                    if(echantillon.getQuantiteStock() + qte < 0){
                        echantillon.setQuantiteStock(Integer.MAX_VALUE);
                    } else {
                        echantillon.setQuantiteStock((echantillon.getQuantiteStock() + qte));
                    }
                    if(bdd.updateEchantillon(echantillon)){
                        txtMessage.setTextColor(messageCouleur);
                        txtMessage.setText("Échantillons ajouter en base !");
                    } else {
                        txtMessage.setTextColor(Color.RED);
                        txtMessage.setText("Érreur lors de l'ajout des échantillons !");
                    }
                } else {
                    txtMessage.setTextColor(Color.RED);
                    txtMessage.setText("Échantillon non trouvé !");
                }
                bdd.close();
            }catch (NumberFormatException nfe){
                txtMessage.setTextColor(Color.RED);
                txtMessage.setText("Quantité invalide !");
            }catch(Exception e){
                txtMessage.setTextColor(Color.RED);
                txtMessage.setText("Veuillez renseigner tout les champs !");
            }

        });
		Button btnSupprimer = findViewById(R.id.btn_supprimer);
		btnSupprimer.setOnClickListener(v -> {
            try{
                code = sp_code.getSelectedItem().toString();
                qte = Integer.parseInt(eTxtStock.getText().toString());
                BdAdapter bdd = new BdAdapter(getBaseContext());
                bdd.open();
                Echantillon echantillon = bdd.getEchantillonWithCode(code);
                if(echantillon != null){
                    echantillon.setQuantiteStock(Math.max(0, echantillon.getQuantiteStock() - qte));
                    if(bdd.updateEchantillon(echantillon)){
                        txtMessage.setTextColor(messageCouleur);
                        txtMessage.setText("Échantillons retirer en base !");
                    } else {
                        txtMessage.setTextColor(Color.RED);
                        txtMessage.setText("Érreur lors de l'ajout des échantillons !");
                    }
                } else {
                    txtMessage.setTextColor(Color.RED);
                    txtMessage.setText("Échantillon non trouvé !");
                }
                bdd.close();
            }catch (NumberFormatException nfe){
                txtMessage.setTextColor(Color.RED);
                txtMessage.setText("Quantité invalide !");
            }catch(Exception e){
                txtMessage.setTextColor(Color.RED);
                txtMessage.setText("Veuillez renseigner tout les champs !");
            }

        });
		Button btnQuitter = findViewById(R.id.btn_quitter);
		btnQuitter.setOnClickListener(v -> finish());
	}

	private void init(){
		txtMessage = findViewById(R.id.txt_message);
		txtMessage.setText("");
		messageCouleur = txtMessage.getCurrentTextColor();
		eTxtStock = findViewById(R.id.eTxt_qte);

        sp_code = findViewById(R.id.sp_code);
        BdAdapter bdd = new BdAdapter(this);
        bdd.open();
        Cursor curseur = bdd.getEchantillonData();
        if(curseur != null && curseur.moveToFirst()) {
            List<String> dataList = new ArrayList<>();
            do {
                // Ajouter chaque valeur du curseur à la liste de données
                String value = curseur.getString(curseur.getColumnIndexOrThrow(EchantillonDao.COL_CODE));
                dataList.add(value);
            } while (curseur.moveToNext());

            // Fermer le curseur après utilisation
            curseur.close();

            // Convertir la liste de données en tableau pour l'adapter du Spinner
            String[] dataArray = dataList.toArray(new String[0]);

            // Utiliser un ArrayAdapter pour lier les données du Spinner
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, dataArray);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            sp_code.setAdapter(adapter);
        }
        bdd.close();
	}
}

package com.example.appligsb.Activite;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.annotation.Nullable;

import com.example.appligsb.R;
import com.example.appligsb.modele.dao.BdAdapter;
import com.example.appligsb.modele.dao.EchantillonDao;

public class ListeActivite extends Activity {
    private ListView lstListe;
    private BdAdapter echantBdd;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activite_liste);
        init();
        Button btnQuitter = findViewById(R.id.btn_quitter);
        btnQuitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    protected void init(){
        lstListe = findViewById(R.id.lst_liste);
        echantBdd = new BdAdapter(this);
        echantBdd.open();
        Cursor curseur = echantBdd.getEchantillonData();
        String[] nomsCol = new String[] {EchantillonDao.COL_CODE, EchantillonDao.COL_LIB, EchantillonDao.COL_STOCK};
        int[] indicesCol = new int[] {R.id.txt_code, R.id.txt_lib, R.id.txt_stock};
        SimpleCursorAdapter adaptDonnees = new SimpleCursorAdapter(this, R.layout.list_entree, curseur, nomsCol, indicesCol);
        lstListe.setAdapter(adaptDonnees);
        echantBdd.close();
    }
}

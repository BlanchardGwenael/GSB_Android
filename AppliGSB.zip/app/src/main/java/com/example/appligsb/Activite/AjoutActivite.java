package com.example.appligsb.Activite;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.appligsb.R;
import com.example.appligsb.modele.Echantillon;
import com.example.appligsb.modele.dao.BdAdapter;

public class AjoutActivite extends Activity {
    TextView txtMessage;
    EditText eTxtCode, eTxtLibele, eTxtStock;
    String code, libelle;
    int messageCouleur, stock;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activite_ajout);
        init();
        Button btnAjouter = findViewById(R.id.btn_ajouter);
        btnAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    code = eTxtCode.getText().toString();
                    libelle = eTxtLibele.getText().toString();
                    stock = Math.min(Integer.parseInt(eTxtStock.getText().toString()), Integer.MAX_VALUE);
                    Echantillon echantillon = new Echantillon(code, libelle, stock);
                    BdAdapter bdd = new BdAdapter(getBaseContext());
                    bdd.open();
                    boolean resultat = bdd.insertEchantillon(echantillon);
                    bdd.close();
                    txtMessage.setTextColor(messageCouleur);
                    txtMessage.setText("Echantillon ajouter en base !");
                }catch (NumberFormatException nfe){
                    txtMessage.setTextColor(Color.RED);
                    txtMessage.setText("Quantité invalide !");
                }catch(Exception e){
                    txtMessage.setTextColor(Color.RED);
                    txtMessage.setText("Veuillez renseigner tout les champs !");
                }

            }
        });
        Button btnQuitter = findViewById(R.id.btn_quitter);
        btnQuitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void init(){
        txtMessage = findViewById(R.id.txt_message);
        txtMessage.setText("");
        messageCouleur = txtMessage.getCurrentTextColor();
        eTxtCode = findViewById(R.id.eTxt_code);
        eTxtLibele = findViewById(R.id.eTxt_libele);
        eTxtStock = findViewById(R.id.eTxt_stock);
    }
}

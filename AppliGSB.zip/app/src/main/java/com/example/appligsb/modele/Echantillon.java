package com.example.appligsb.modele;

public class Echantillon {
    private  String code, libelle;
    private int quantiteStock;

    public Echantillon(String code, String libelle, int quantiteStock){
        this.code = code;
        this.libelle = libelle;
        this.quantiteStock = quantiteStock;
    }
    public Echantillon(){
        this.code = "none";
        this.libelle = "none";
        this.quantiteStock = 0;
    }
    public String getCode(){
        return this.code;
    }

    public void setCode(String code){
        this.code = code;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getQuantiteStock() {
        return quantiteStock;
    }

    public void setQuantiteStock(int quantiteStock) {
        this.quantiteStock = quantiteStock;
    }
}

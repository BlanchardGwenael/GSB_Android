package com.example.appligsb.Activite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.appligsb.R;
import com.example.appligsb.modele.Echantillon;
import com.example.appligsb.modele.dao.BdAdapter;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jeuEssaiBd();
        Button btnAjout = (Button)findViewById(R.id.btn_ajouterEchantillon);
        Button btnListe = (Button)findViewById(R.id.btn_listeEchantillons);
        Button btnMaj = (Button)findViewById(R.id.btn_majEchantillon);
        Button btnListeMouvAjout = (Button)findViewById(R.id.btn_listeMouvAjout);
        Button btnListeMouvSupp = (Button)findViewById(R.id.btn_listeMouvSupp);
        btnAjout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AjoutActivite.class);
                startActivity(intent);
            }
        });
        btnListe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListeActivite.class);
                startActivity(intent);
            }
        });
        btnMaj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MajActivite.class);
                startActivity(intent);
            }
        });
        btnListeMouvAjout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListeMouvementAjoutActivite.class);
                startActivity(intent);
            }
        });
        btnListeMouvSupp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListeMouvementSuppressionActivite.class);
                startActivity(intent);
            }
        });
    }

    public void jeuEssaiBd(){
        BdAdapter echanBdd = new BdAdapter(this);

        echanBdd.open();
        if(echanBdd.getEchantillonData() != null){
            if(echanBdd.getEchantillonData().getCount() != 0){
                echanBdd.resetDataBase();
            }
        }

        echanBdd.insertEchantillon(new Echantillon("code1", "lib1", 3));
        echanBdd.insertEchantillon(new Echantillon("code2", "lib2", 5));
        echanBdd.insertEchantillon(new Echantillon("code3", "lib3", 7));
        echanBdd.insertEchantillon(new Echantillon("code4", "lib4", 6));
        Cursor c = echanBdd.getEchantillonData();
        if(c != null) {
            System.out.println("Il y a " + c.getCount() + " echantillons dans la BDD !");
        } else {
            System.out.println("Il y a une erreur avec la BDD !");
        }
        echanBdd.close();
    }
}